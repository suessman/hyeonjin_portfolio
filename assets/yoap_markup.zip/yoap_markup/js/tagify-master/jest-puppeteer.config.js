module.exports = {
  launch: {
    slowMo  : 80,
    headless: true,
  },
  browserContext: 'default',
}